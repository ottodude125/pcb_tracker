ActionController::Base.send :include, AutoComplete
ActionController::Base.helper AutoCompleteMacrosHelper